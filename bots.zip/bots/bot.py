import telebot
from telebot import types
import random

bot = telebot.TeleBot('5702611908:AAFFbTKXcboB0VOFEUYCzDnL7U3f1bEDAhY')


@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    item1 = types.KeyboardButton('⛔ Правила во время(Тестирования)')
    item2 = types.KeyboardButton('📌 Cайт Oqylyq')
    item3 = types.KeyboardButton('💻 Видео помощь(Времено не работает)')
    item4 = types.KeyboardButton('📷 Фото помощь')
    item5 = types.KeyboardButton('❄ Рандомное число')

    markup.add(item1, item2, item3, item4, item5)

    bot.send_message(message.chat.id, 'Привет, {0.first_name}'.format(message.from_user), reply_markup=markup)


@bot.message_handler(content_types=['text'])
def bot_message(message):
    if message.chat.type == 'private':
        if message.text == '❄ Рандомное число':
            bot.send_message(message.chat.id, 'Ваше число: '+ str(random.randint(0, 1000)))
        elif message.text == '⛔ Правила во время(Тестирования)':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item1 = types.KeyboardButton('❶Компьютерное тестирование(онлайн)')
            item2 = types.KeyboardButton('❷Компьютерное тестирование(оффлайн)')
            item3 = types.KeyboardButton('❸Письменный экзамен')
            item4 = types.KeyboardButton('❹Письменный экзамен (Открытая книга)')
            item5 = types.KeyboardButton('❺Практический экзамен')
            item6 = types.KeyboardButton('❻Проектный экзамен')
            back = types.KeyboardButton('🤔Назад')
            markup.add(item1, item2, item3, item4, item5, item6, back)

            bot.send_message(message.chat.id, '⛔ Правила во время(Тестирования)', reply_markup=markup)

        elif message.text == '❶Компьютерное тестирование(онлайн)':
            file = open('pravilo_1.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '❷Компьютерное тестирование(оффлайн)':
            file = open('pravilo_2.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '❸Письменный экзамен':
            file = open('pravilo_3.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '❹Письменный экзамен (Открытая книга)':
            file = open('pravilo_4.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '❺Практический экзамен':
            file = open('pravilo_5.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '❻Проектный экзамен':
            file = open('pravilo_6.jpg', 'rb')
            bot.send_photo(message.chat.id, file)

        elif message.text == '📌 Cайт Oqylyq':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)    
            item1 = types.InlineKeyboardButton('🔽Сайт')
            back = types.KeyboardButton('🤔Назад')
            markup.add(item1, back)

            bot.send_message(message.chat.id, '📌 Cайт Oqylyq', reply_markup=markup)
        elif message.text == '🔽Сайт':
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton('Посетить сайт', url='https://oqylyq.kz/'))

            bot.send_message(message.chat.id, '📌 Cайт Oqylyq', reply_markup=markup)

        elif message.text == '💻 Видео помощь(Времено не работает)':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item1 = types.InlineKeyboardButton('🔸Создание и сдача экзамена в системе(нужно немного подождать)')
            back = types.KeyboardButton('🤔Назад')
            markup.add(item1, back)

            bot.send_message(message.chat.id, '💻 Видео помощь', reply_markup=markup)

        elif message.text == '🔸Создание и сдача экзамена в системе(нужно немного подождать)':
            file = open('', 'rb')
            bot.send_video(message.chat.id, file)

        elif message.text == '📷 Фото помощь':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item1 = types.InlineKeyboardButton('🔸ДОБАВЛЕНИЕ ВОПРОСОВ В СДО OQYLYQ')
            item2 = types.InlineKeyboardButton('🔸СОЗДАНИЕ ЭКЗАМЕНА В СДО OQYLYQ')
            back = types.KeyboardButton('🤔Назад')
            markup.add(item1, item2, back)

            bot.send_message(message.chat.id, '📷 Фото помощь', reply_markup=markup)

        elif message.text == '🔸ДОБАВЛЕНИЕ ВОПРОСОВ В СДО OQYLYQ':
            file = open('instr1.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '1)После входа в систему Oqylyq вы попадете на Главную страницу. Далее слева в меню зайдите во вкладку Тесты. ')

            file = open('instr2.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '2)Для создания нового комплекта вопросов нажмите на кнопку “Новый тест” ')

            file = open('instr3.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '3)Название своей дисциплины (название должно совпадать с названием дисциплины, указанной в системе Универ, а также в соответствии с языком обучения). Пример: если обучение на русском языке, то пишем - Международное публичное право. Если обучение на казахском языке, то пишем - Халықаралық жария құқық, если обучение на английском языке, пишем - International public law.')

            file = open('instr4.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '4)В поле Описание впишите данные в следующем порядке :Специальность. Пример: Юриспруденция.Курс. Пример: 3 курс.	Вид экзамена. Пример: Закрытая книга')

            file = open('instr5.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '5)Теперь необходимо заполнить его вопросами. Для того чтобы добавить вопрос вам надо нажать на кнопку «+» (кнопка находиться под описанием). Далее выбираем тип вопроса - Открытый вопрос. ')

            file = open('instr6.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '6)Добавление нового вопроса в комплект')

            file = open('instr7.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '7)После нажатия откроется лист с пустыми полями.  ')

            file = open('instr8.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '8)Добавление нового вопроса в комплект')

            file = open('instr9.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '9)Для добавления картинок воспользуйтесь кнопкой с картинкой. Далее выберите «Upload» и перенесите изображение либо нажмите на «Browse».')

            file = open('instr10.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '10)Для добавления видео нажмите на изображение звеньев. В поле URL вставьте ссылку на видео. После загрузки видео нажмите «Save»')

            file = open('instr11.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '11)Функции для добавления математических и химических формулДля работы с математическими формулами нажмите на картинку корня, для химических – на «С». В редакторах формул можно их вставлять с помощью кнопок или использовать функцию рукописного ввода.')

            file = open('instr12.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '12)Один вопрос готов. Чтобы добавить еще вопросы вернитесь на шаг создание вопроса – Рисунок 6.')

            file = open('instr13.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '13)После добавление достаточного количества вопросов вы можете нажать на кнопку «Сохранить» (сверху справа) и выйти на Главную страницу.')

        elif message.text == '🔸СОЗДАНИЕ ЭКЗАМЕНА В СДО OQYLYQ':
            file = open('sozd1.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '1)Для проведения экзамена в СДО Oqylyq вам нужно перейти во вкладку «Задания» ')

            file = open('sozd2.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '2)В открывшейся странице выйдет список всех созданных вами экзаменов. Для того, чтобы создать новый экзамен, нажмите на кнопку «Новое задание»')

            file = open('sozd3.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '3)Чтобы назначить экзамен, вам необходимо: Тип задания – переключите значок с «Урок» на «Экзамен»Материал – нажимаем на кнопку «Выбрать вопросник» выбираем ваш созданный комплект вопросов и нажмите «Готово» ')

            file = open('sozd4.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '4)Ревьювер (член комиссии который тоже будет проверять работы студентов) – нажимаем «Добавить ревьювера» откроется окно с поиском. В поле поиска напишите Имя или Фамилю преподавателя. (Ревьювера назначает кафедра). Выберите преподавателя и нажмите «Готово» ')

            file = open('sozd5.jpg', 'rb')
            bot.send_photo(message.chat.id, file)
            bot.send_message(message.chat.id, '5)Класс / Группа – нажмите на кнопку «Выбрать группу» откроется окно со список прикрепленных к вам групп (группы отображаются в виде номеров аттестационной ведомости). Выберите нужную вам группу и нажмите «Готово» ')




        elif message.text == '🤔Назад':
            markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
            item1 = types.KeyboardButton('⛔ Правила во время(Тестирования)')
            item2 = types.KeyboardButton('📌 Cайт Oqylyq')
            item3 = types.KeyboardButton('💻 Видео помощь(Времено не работает)')
            item4 = types.KeyboardButton('📷 Фото помощь')
            item5 = types.KeyboardButton('❄ Рандомное число')

            markup.add(item1, item2, item3, item4, item5)

            bot.send_message(message.chat.id, '🤔Назад', reply_markup=markup)

        else:
            bot.send_message(message.chat.id, 'Я тебя не понимаю, напиши&#128514;  /start ', parse_mode='html')


bot.polling(none_stop=True)
